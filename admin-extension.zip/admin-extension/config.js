export const DEFAULT_SERVER_BASE_URL = "https://publicpass.mohsin-yousufi.workers.dev";
export const API_TIMEOUT_MS = 20000;
